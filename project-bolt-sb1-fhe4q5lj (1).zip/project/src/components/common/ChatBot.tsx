import React, { useState, useRef, useEffect } from 'react';
import { MessageSquare, Send, X, MinusSquare, Maximize2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAuth } from '../../contexts/AuthContext';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'bot';
  timestamp: Date;
}

const INITIAL_MESSAGES: Message[] = [
  {
    id: '1',
    text: "Hey there! 👋 I'm your campus buddy. How can I help you today?",
    sender: 'bot',
    timestamp: new Date(),
  }
];

const PREDEFINED_RESPONSES: Record<string, string> = {
  'hello': "Hey rockstar! 😎 How's your day going?",
  'hi': "Hi there! 👋 What can I help you with today?",
  'how many black marks': "The suspension limit is 5 black marks in a semester. You currently have 2 - be careful! 😅",
  'show my grades': "I can see your grades for this semester: Math (A-), Physics (B+), Literature (A). Keep up the good work! 🌟",
  'i\'m stressed': "College can be tough! 🫂 Try taking a 10-minute break, deep breathing, or a quick walk. Remember, it's okay to ask for help from your mentors!",
  'what\'s today\'s event': "Today we have a Tech Talk at 3PM in the main auditorium and a Basketball match at 5PM! 🏀",
  'syllabus': "Your Mathematics syllabus is 67% complete, Physics is at 58%, and Literature is at 72%. Need more details?",
  'study tip': "Try the Pomodoro Technique: 25 minutes of focused study, then a 5-minute break. Repeat 4 times, then take a longer break. Your brain will thank you! 🧠⏱️",
  'coding competition': "There's a hackathon coming up this weekend! Registration closes tomorrow at 5PM. Want me to send you the link?",
};

const ChatBot: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [messages, setMessages] = useState<Message[]>(INITIAL_MESSAGES);
  const [input, setInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { currentUser } = useAuth();

  // Scroll to bottom when messages change
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  const toggleChat = () => {
    setIsOpen(!isOpen);
    setIsMinimized(false);
  };

  const toggleMinimize = () => {
    setIsMinimized(!isMinimized);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInput(e.target.value);
  };

  const findResponse = (text: string): string => {
    text = text.toLowerCase();
    
    // Check for matches in predefined responses
    for (const [key, value] of Object.entries(PREDEFINED_RESPONSES)) {
      if (text.includes(key)) {
        return value;
      }
    }
    
    // Generic responses if no match
    if (text.includes('thank')) {
      return "You're welcome! Anything else I can help with? 😊";
    }
    
    if (text.includes('bye') || text.includes('goodbye')) {
      return "See you later! Have a great day! 👋";
    }
    
    return "I'm not sure about that. Can you try asking something about your classes, grades, events, or black marks? 🤔";
  };

  const handleSendMessage = () => {
    if (!input.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: input,
      sender: 'user',
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');

    // Simulate bot response after a short delay
    setTimeout(() => {
      const botResponse: Message = {
        id: (Date.now() + 1).toString(),
        text: findResponse(input),
        sender: 'bot',
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, botResponse]);
    }, 800);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSendMessage();
    }
  };

  return (
    <>
      {/* Chat toggle button */}
      <button
        onClick={toggleChat}
        className="fixed bottom-6 right-6 bg-blue-600 text-white p-3 rounded-full shadow-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50 z-50"
      >
        <MessageSquare size={24} />
      </button>

      {/* Chat window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            transition={{ duration: 0.2 }}
            className="fixed bottom-20 right-6 bg-white dark:bg-gray-800 rounded-lg shadow-xl w-80 md:w-96 z-50 overflow-hidden"
            style={{ maxHeight: '600px' }}
          >
            {/* Chat header */}
            <div className="bg-blue-600 dark:bg-blue-800 text-white p-3 flex justify-between items-center">
              <h3 className="font-medium">Campus Buddy</h3>
              <div className="flex items-center space-x-2">
                <button
                  onClick={toggleMinimize}
                  className="text-white hover:text-gray-200 focus:outline-none"
                >
                  {isMinimized ? <Maximize2 size={18} /> : <MinusSquare size={18} />}
                </button>
                <button
                  onClick={toggleChat}
                  className="text-white hover:text-gray-200 focus:outline-none"
                >
                  <X size={18} />
                </button>
              </div>
            </div>

            {/* Chat messages */}
            {!isMinimized && (
              <>
                <div className="p-3 overflow-y-auto" style={{ maxHeight: '400px' }}>
                  {messages.map((message) => (
                    <div
                      key={message.id}
                      className={`mb-3 flex ${
                        message.sender === 'user' ? 'justify-end' : 'justify-start'
                      }`}
                    >
                      <div
                        className={`max-w-[80%] rounded-lg px-4 py-2 ${
                          message.sender === 'user'
                            ? 'bg-blue-600 text-white'
                            : 'bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-white'
                        }`}
                      >
                        <p className="text-sm">{message.text}</p>
                        <p className="text-xs opacity-70 mt-1">
                          {message.timestamp.toLocaleTimeString([], {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </p>
                      </div>
                    </div>
                  ))}
                  <div ref={messagesEndRef} />
                </div>

                {/* Chat input */}
                <div className="p-3 border-t border-gray-200 dark:border-gray-700">
                  <div className="flex items-center space-x-2">
                    <input
                      type="text"
                      value={input}
                      onChange={handleInputChange}
                      onKeyPress={handleKeyPress}
                      placeholder="Type your message..."
                      className="flex-1 rounded-full px-4 py-2 bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                    <button
                      onClick={handleSendMessage}
                      className="bg-blue-600 text-white p-2 rounded-full hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <Send size={18} />
                    </button>
                  </div>
                  <div className="mt-2 text-xs text-gray-500 dark:text-gray-400 text-center">
                    Ask me about classes, events, grades, or black marks!
                  </div>
                </div>
              </>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default ChatBot;