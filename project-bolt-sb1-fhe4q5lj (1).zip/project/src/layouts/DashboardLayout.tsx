import React, { useState } from 'react';
import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import { 
  Menu, X, Home, Calendar, BookOpen, Trophy, 
  Smile, AlertTriangle, User, Users, Settings, 
  Bell, LogOut, Moon, Sun, MessageSquare, Award,
  FileText, 
} from 'lucide-react';

import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { useNotifications } from '../contexts/NotificationContext';
import NotificationsDropdown from '../components/common/NotificationsDropdown';

const DashboardLayout: React.FC = () => {
  const { currentUser, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const { unreadCount } = useNotifications();
  const navigate = useNavigate();
  const location = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const toggleNotifications = () => {
    setNotificationsOpen(!notificationsOpen);
  };

  const getNavigationItems = () => {
    const commonItems = [
      { name: 'Dashboard', icon: <Home size={20} />, path: `/dashboard/${currentUser?.role}` },
      { name: 'Timetable', icon: <Calendar size={20} />, path: `/dashboard/${currentUser?.role}/timetable` },
    ];

    const roleSpecificItems = {
      student: [
        { name: 'Syllabus', icon: <BookOpen size={20} />, path: '/dashboard/student/syllabus' },
        { name: 'Competitions', icon: <Trophy size={20} />, path: '/dashboard/student/competitions' },
        { name: 'Events', icon: <Award size={20} />, path: '/dashboard/student/events' },
        { name: 'Feedback', icon: <Smile size={20} />, path: '/dashboard/student/feedback' },
        { name: 'Black Marks', icon: <AlertTriangle size={20} />, path: '/dashboard/student/black-marks' },
        { name: 'Results', icon: <FileText size={20} />, path: '/dashboard/student/results' },
      ],
      faculty: [
        { name: 'Students', icon: <Users size={20} />, path: '/dashboard/faculty/students' },
        { name: 'Feedback', icon: <Smile size={20} />, path: '/dashboard/faculty/feedback' },
        { name: 'Black Marks', icon: <AlertTriangle size={20} />, path: '/dashboard/faculty/black-marks' },
      ],
      admin: [
        { name: 'Users', icon: <Users size={20} />, path: '/dashboard/admin/users' },
        { name: 'Feedback', icon: <Smile size={20} />, path: '/dashboard/admin/feedback' },
        { name: 'Black Marks', icon: <AlertTriangle size={20} />, path: '/dashboard/admin/black-marks' },
        { name: 'Reports', icon: <FileText size={20} />, path: '/dashboard/admin/reports' },
        { name: 'Settings', icon: <Settings size={20} />, path: '/dashboard/admin/settings' },
      ],
    };

    return [
      ...commonItems,
      ...(currentUser?.role ? roleSpecificItems[currentUser.role] : []),
    ];
  };

  return (
    <div className="flex h-screen bg-gray-100 dark:bg-gray-900">
      {/* Sidebar */}
      <div
        className={`${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full'
        } fixed inset-y-0 left-0 z-30 w-64 bg-white dark:bg-gray-800 shadow-lg transform transition-transform duration-300 ease-in-out md:translate-x-0 md:static md:w-64`}
      >
        <div className="flex flex-col h-full">
          {/* Sidebar header */}
          <div className="flex items-center justify-between px-4 py-5 border-b border-gray-200 dark:border-gray-700">
            <div className="flex items-center space-x-2">
              <div className="p-2 bg-blue-500 text-white rounded-lg">
                <BookOpen size={24} />
              </div>
              <h1 className="text-xl font-bold text-gray-800 dark:text-white">College Mentor</h1>
            </div>
            <button
              className="p-1 rounded-md text-gray-500 hover:text-gray-800 dark:text-gray-400 dark:hover:text-white md:hidden"
              onClick={() => setSidebarOpen(false)}
            >
              <X size={24} />
            </button>
          </div>

          {/* Sidebar content */}
          <div className="flex-1 overflow-y-auto py-4 px-3">
            <ul className="space-y-2">
              {getNavigationItems().map((item) => (
                <li key={item.path}>
                  <a
                    href={item.path}
                    onClick={(e) => {
                      e.preventDefault();
                      navigate(item.path);
                      setSidebarOpen(false);
                    }}
                    className={`flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 ${
                      location.pathname === item.path
                        ? 'bg-blue-50 text-blue-600 dark:bg-blue-900/20 dark:text-blue-400'
                        : ''
                    }`}
                  >
                    <span className="mr-3">{item.icon}</span>
                    <span>{item.name}</span>
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Sidebar footer */}
          <div className="p-4 border-t border-gray-200 dark:border-gray-700">
            <div className="flex items-center space-x-3">
              <img
                src={currentUser?.avatarUrl || `https://ui-avatars.com/api/?name=${currentUser?.name}`}
                alt="User avatar"
                className="h-10 w-10 rounded-full"
              />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-800 dark:text-white truncate">
                  {currentUser?.name}
                </p>
                <p className="text-xs text-gray-500 dark:text-gray-400 truncate">
                  {currentUser?.role.charAt(0).toUpperCase() + currentUser?.role.slice(1)}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top navbar */}
        <header className="bg-white dark:bg-gray-800 shadow-sm z-10">
          <div className="flex items-center justify-between px-4 py-3">
            <button
              className="p-1 rounded-md text-gray-500 hover:text-gray-800 focus:outline-none md:hidden"
              onClick={() => setSidebarOpen(true)}
            >
              <Menu size={24} />
            </button>

            {/* Search bar - could be implemented later */}
            <div className="flex-1 mx-4 md:mx-8 hidden md:block">
              <h1 className="text-xl font-semibold text-gray-800 dark:text-white">
                {currentUser?.role === 'student' ? 'Student Portal' : 
                 currentUser?.role === 'faculty' ? 'Faculty Portal' : 'Admin Portal'}
              </h1>
            </div>

            {/* Right side icons */}
            <div className="flex items-center space-x-4">
              <button
                onClick={toggleTheme}
                className="p-1 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-500 dark:text-gray-400"
              >
                {theme === 'dark' ? <Sun size={20} /> : <Moon size={20} />}
              </button>

              <button
                onClick={toggleNotifications}
                className="p-1 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-500 dark:text-gray-400 relative"
              >
                <Bell size={20} />
                {unreadCount > 0 && (
                  <span className="absolute top-0 right-0 h-4 w-4 bg-red-500 rounded-full text-xs text-white flex items-center justify-center transform translate-x-1 -translate-y-1">
                    {unreadCount}
                  </span>
                )}
              </button>

              <button
                onClick={() => {}}
                className="p-1 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-500 dark:text-gray-400"
              >
                <MessageSquare size={20} />
              </button>

              <button
                onClick={handleLogout}
                className="p-1 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-500 dark:text-gray-400"
              >
                <LogOut size={20} />
              </button>
            </div>
          </div>
        </header>

        {/* Notifications dropdown */}
        {notificationsOpen && (
          <div className="absolute right-0 mt-12 mr-4 z-50">
            <NotificationsDropdown onClose={() => setNotificationsOpen(false)} />
          </div>
        )}

        {/* Main content area */}
        <main className="flex-1 overflow-y-auto bg-gray-50 dark:bg-gray-900 p-4 md:p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default DashboardLayout;