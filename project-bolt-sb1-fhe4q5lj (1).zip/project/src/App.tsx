import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { ThemeProvider } from './contexts/ThemeContext';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { NotificationProvider } from './contexts/NotificationContext';

// Layouts
import DashboardLayout from './layouts/DashboardLayout';

// Auth Pages
import Login from './pages/auth/Login';
import Register from './pages/auth/Register';
import ForgotPassword from './pages/auth/ForgotPassword';

// Dashboard Pages
import StudentDashboard from './pages/student/Dashboard';
import FacultyDashboard from './pages/faculty/Dashboard';
import AdminDashboard from './pages/admin/Dashboard';

// Student Pages
import Timetable from './pages/student/Timetable';
import Syllabus from './pages/student/Syllabus';
import Competitions from './pages/student/Competitions';
import Events from './pages/student/Events';
import StudentFeedback from './pages/student/Feedback';
import StudentBlackMarks from './pages/student/BlackMarks';
import Results from './pages/student/Results';

// Faculty Pages
import FacultyTimetable from './pages/faculty/Timetable';
import FacultyFeedback from './pages/faculty/Feedback';
import FacultyBlackMarks from './pages/faculty/BlackMarks';
import StudentManagement from './pages/faculty/StudentManagement';

// Admin Pages
import AdminUsers from './pages/admin/Users';
import AdminFeedback from './pages/admin/Feedback';
import AdminBlackMarks from './pages/admin/BlackMarks';
import AdminSettings from './pages/admin/Settings';
import AdminReports from './pages/admin/Reports';

// Components
import ChatBot from './components/common/ChatBot';
import PrivateRoute from './components/auth/PrivateRoute';

function App() {
  return (
    <Router>
      <ThemeProvider>
        <AuthProvider>
          <NotificationProvider>
            <AppRoutes />
            <ChatBot />
          </NotificationProvider>
        </AuthProvider>
      </ThemeProvider>
    </Router>
  );
}

const AppRoutes = () => {
  const { currentUser, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-100 dark:bg-gray-900 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <Routes>
      {/* Auth Routes */}
      <Route 
        path="/login" 
        element={currentUser ? <Navigate to="/dashboard" /> : <Login />} 
      />
      <Route 
        path="/register" 
        element={currentUser ? <Navigate to="/dashboard" /> : <Register />} 
      />
      <Route path="/forgot-password" element={<ForgotPassword />} />

      {/* Dashboard Routes */}
      <Route 
        path="/dashboard" 
        element={
          <PrivateRoute>
            <DashboardLayout />
          </PrivateRoute>
        }
      >
        {/* Student Routes */}
        <Route 
          path="" 
          element={<Navigate to={currentUser?.role === 'student' ? 'student' : currentUser?.role === 'faculty' ? 'faculty' : 'admin'} />} 
        />
        <Route path="student" element={<StudentDashboard />} />
        <Route path="student/timetable" element={<Timetable />} />
        <Route path="student/syllabus" element={<Syllabus />} />
        <Route path="student/competitions" element={<Competitions />} />
        <Route path="student/events" element={<Events />} />
        <Route path="student/feedback" element={<StudentFeedback />} />
        <Route path="student/black-marks" element={<StudentBlackMarks />} />
        <Route path="student/results" element={<Results />} />

        {/* Faculty Routes */}
        <Route path="faculty" element={<FacultyDashboard />} />
        <Route path="faculty/timetable" element={<FacultyTimetable />} />
        <Route path="faculty/feedback" element={<FacultyFeedback />} />
        <Route path="faculty/black-marks" element={<FacultyBlackMarks />} />
        <Route path="faculty/students" element={<StudentManagement />} />

        {/* Admin Routes */}
        <Route path="admin" element={<AdminDashboard />} />
        <Route path="admin/users" element={<AdminUsers />} />
        <Route path="admin/feedback" element={<AdminFeedback />} />
        <Route path="admin/black-marks" element={<AdminBlackMarks />} />
        <Route path="admin/settings" element={<AdminSettings />} />
        <Route path="admin/reports" element={<AdminReports />} />
      </Route>

      {/* Redirect to login if no match */}
      <Route path="*" element={<Navigate to="/login" />} />
    </Routes>
  );
};

export default App;