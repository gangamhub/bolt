import React, { useState } from 'react';
import { 
  AlertTriangle, Search, Filter, Users, Check, X, 
  ChevronDown, ChevronUp, RefreshCw, AlertCircle,
  XCircle, CheckCircle 
} from 'lucide-react';
import { useNotifications } from '../../contexts/NotificationContext';

// Mock data for black marks (all across the college)
const allBlackMarks = [
  { 
    id: 1, 
    studentId: 1, 
    studentName: 'John Smith',
    rollNumber: 'S20210001',
    program: 'Computer Science',
    year: 2,
    reason: 'Late to class', 
    date: '2025-05-10', 
    severity: 'low',
    facultyName: 'Dr. Williams',
    facultyDepartment: 'Computer Science',
    subject: 'Database Systems',
    details: 'Arrived 15 minutes late to class without prior notification.',
    status: 'pending', // 'pending', 'approved', 'rejected'
    reviewedBy: null,
    parentNotified: false,
    blackMarkCount: 2,
    parentContact: '+1-555-123-4567',
    studentResponse: null,
    classRepVerified: true,
    hodApproved: false
  },
  { 
    id: 2, 
    studentId: 2, 
    studentName: 'Emily Johnson',
    rollNumber: 'S20210002',
    program: 'Physics',
    year: 2,
    reason: 'Missing assignment', 
    date: '2025-05-01', 
    severity: 'medium',
    facultyName: 'Prof. Anderson',
    facultyDepartment: 'Physics',
    subject: 'Quantum Mechanics',
    details: 'Failed to submit the assignment by the deadline without requesting an extension.',
    status: 'approved',
    reviewedBy: 'Prof. Davis (HoD)',
    parentNotified: true,
    blackMarkCount: 1,
    parentContact: '+1-555-987-6543',
    studentResponse: 'I was sick and forgot to inform you. Sorry.',
    classRepVerified: true,
    hodApproved: true
  },
  { 
    id: 3, 
    studentId: 3, 
    studentName: 'Michael Brown',
    rollNumber: 'S20210003',
    program: 'Mathematics',
    year: 2,
    reason: 'Disruptive behavior', 
    date: '2025-04-15', 
    severity: 'high',
    facultyName: 'Dr. Roberts',
    facultyDepartment: 'Mathematics',
    subject: 'Calculus III',
    details: 'Repeatedly talking and disrupting the class during a lecture despite warnings.',
    status: 'rejected',
    reviewedBy: 'Prof. Smith (HoD)',
    parentNotified: false,
    blackMarkCount: 4,
    parentContact: '+1-555-456-7890',
    studentResponse: 'I apologize for my behavior. It won\'t happen again.',
    classRepVerified: false,
    hodApproved: false
  },
  { 
    id: 4, 
    studentId: 4, 
    studentName: 'Sarah Williams',
    rollNumber: 'S20210004',
    program: 'English Literature',
    year: 2,
    reason: 'Plagiarism', 
    date: '2025-04-05', 
    severity: 'high',
    facultyName: 'Prof. Johnson',
    facultyDepartment: 'English',
    subject: 'Modern Literature',
    details: 'Submitted an essay with significant portions copied from online sources without proper citation.',
    status: 'approved',
    reviewedBy: 'Prof. Wilson (HoD)',
    parentNotified: true,
    blackMarkCount: 3,
    parentContact: '+1-555-789-0123',
    studentResponse: 'I didn\'t understand the citation rules. I\'ll be more careful next time.',
    classRepVerified: true,
    hodApproved: true
  },
];

const AdminBlackMarks: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filter, setFilter] = useState('all'); // 'all', 'pending', 'approved', 'rejected'
  const [sortBy, setSortBy] = useState('date'); // 'date', 'severity', 'student'
  const [expandedId, setExpandedId] = useState<number | null>(null);
  const { addNotification } = useNotifications();
  
  const toggleExpand = (id: number) => {
    if (expandedId === id) {
      setExpandedId(null);
    } else {
      setExpandedId(id);
    }
  };

  const filteredBlackMarks = allBlackMarks
    .filter(mark => {
      // Filter by status
      if (filter !== 'all' && mark.status !== filter) return false;
      
      // Filter by search term
      const searchText = (
        mark.studentName + 
        mark.rollNumber +
        mark.reason + 
        mark.facultyName +
        mark.subject
      ).toLowerCase();
      
      return searchText.includes(searchTerm.toLowerCase());
    })
    .sort((a, b) => {
      // Sort by selected criterion
      if (sortBy === 'date') {
        return new Date(b.date).getTime() - new Date(a.date).getTime();
      } else if (sortBy === 'severity') {
        const severityOrder = { low: 1, medium: 2, high: 3 };
        return severityOrder[b.severity as keyof typeof severityOrder] - 
               severityOrder[a.severity as keyof typeof severityOrder];
      } else if (sortBy === 'student') {
        return a.studentName.localeCompare(b.studentName);
      }
      return 0;
    });

  const handleApproveBlackMark = (id: number) => {
    // In a real app, this would be an API call
    console.log('Approving black mark:', id);
    
    // Show notification
    addNotification({
      type: 'success',
      title: 'Black Mark Approved',
      message: 'The black mark has been approved and recorded in the student\'s file.',
    });
  };

  const handleRejectBlackMark = (id: number) => {
    // In a real app, this would be an API call
    console.log('Rejecting black mark:', id);
    
    // Show notification
    addNotification({
      type: 'info',
      title: 'Black Mark Rejected',
      message: 'The black mark has been rejected and will not be recorded.',
    });
  };

  const handleNotifyParent = (id: number) => {
    // In a real app, this would be an API call
    console.log('Notifying parent for black mark:', id);
    
    // Show notification
    addNotification({
      type: 'success',
      title: 'Parent Notified',
      message: 'A notification has been sent to the student\'s parent/guardian.',
    });
  };

  const getStatusClass = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-400';
      case 'approved':
        return 'bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-400';
      case 'rejected':
        return 'bg-red-100 dark:bg-red-900/30 text-red-800 dark:text-red-400';
      default:
        return 'bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-400';
    }
  };

  const getSeverityClass = (severity: string) => {
    switch (severity) {
      case 'low':
        return 'bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-400';
      case 'medium':
        return 'bg-orange-100 dark:bg-orange-900/30 text-orange-800 dark:text-orange-400';
      case 'high':
        return 'bg-red-100 dark:bg-red-900/30 text-red-800 dark:text-red-400';
      default:
        return 'bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-400';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-800 dark:text-white flex items-center">
              <AlertTriangle className="mr-2 text-yellow-500" size={24} />
              College-wide Black Marks
            </h1>
            <p className="text-gray-600 dark:text-gray-400 mt-1">
              Manage and review all black marks across departments
            </p>
          </div>
          
          <div className="mt-4 md:mt-0">
            <button
              onClick={() => addNotification({
                type: 'info',
                title: 'Refreshed Data',
                message: 'Black marks data has been refreshed from the database.',
              })}
              className="inline-flex items-center px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm text-sm font-medium text-gray-700 dark:text-gray-200 bg-white dark:bg-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              <RefreshCw size={16} className="mr-2" />
              Refresh Data
            </button>
          </div>
        </div>
      </div>

      {/* Filters and Search */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4">
        <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-4">
          <div className="relative flex-1">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search size={18} className="text-gray-400" />
            </div>
            <input
              type="text"
              className="block w-full pl-10 pr-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md leading-5 bg-white dark:bg-gray-700 placeholder-gray-500 focus:outline-none focus:ring-blue-500 focus:border-blue-500 text-gray-900 dark:text-white sm:text-sm"
              placeholder="Search by student, faculty, or reason..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <div className="flex space-x-4">
            <select
              className="block w-full pl-3 pr-10 py-2 text-base border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
            >
              <option value="all">All Statuses</option>
              <option value="pending">Pending</option>
              <option value="approved">Approved</option>
              <option value="rejected">Rejected</option>
            </select>
            
            <select
              className="block w-full pl-3 pr-10 py-2 text-base border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
            >
              <option value="date">Sort by Date</option>
              <option value="severity">Sort by Severity</option>
              <option value="student">Sort by Student</option>
            </select>
          </div>
        </div>
      </div>

      {/* Black Marks List */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow">
        {filteredBlackMarks.length === 0 ? (
          <div className="p-6 text-center">
            <AlertCircle size={48} className="mx-auto mb-4 text-gray-400" />
            <h3 className="text-lg font-medium text-gray-800 dark:text-white">No black marks found</h3>
            <p className="text-gray-600 dark:text-gray-400 mt-1">
              {searchTerm 
                ? 'No results match your search criteria' 
                : 'There are no black marks in the system'}
            </p>
          </div>
        ) : (
          <ul className="divide-y divide-gray-200 dark:divide-gray-700">
            {filteredBlackMarks.map((mark) => (
              <li key={mark.id} className="p-4 hover:bg-gray-50 dark:hover:bg-gray-750">
                <div 
                  className="flex justify-between items-start cursor-pointer"
                  onClick={() => toggleExpand(mark.id)}
                >
                  <div className="flex items-start">
                    <div className={`p-2 rounded-full mr-4 ${getSeverityClass(mark.severity)}`}>
                      <AlertTriangle size={20} />
                    </div>
                    <div>
                      <h3 className="font-medium text-gray-800 dark:text-white">{mark.reason}</h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        Student: {mark.studentName} ({mark.rollNumber}) • {mark.program}
                      </p>
                      <p className="text-sm text-gray-500 dark:text-gray-500">
                        Faculty: {mark.facultyName} • {mark.subject} • {new Date(mark.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium capitalize mr-2 ${getStatusClass(mark.status)}`}>
                      {mark.status}
                    </span>
                    {expandedId === mark.id ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
                  </div>
                </div>
                
                {/* Expanded details */}
                {expandedId === mark.id && (
                  <div className="mt-4 pl-12 border-t border-gray-200 dark:border-gray-700 pt-4">
                    <div className="mb-3">
                      <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300">Details:</h4>
                      <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">{mark.details}</p>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                      <div>
                        <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300">Verification Status:</h4>
                        <div className="mt-1 flex space-x-4">
                          <div className="flex items-center">
                            <span className={`inline-flex items-center justify-center w-5 h-5 rounded-full mr-1.5 ${
                              mark.classRepVerified ? 'bg-green-100 dark:bg-green-900/30' : 'bg-red-100 dark:bg-red-900/30'
                            }`}>
                              {mark.classRepVerified ? (
                                <Check size={12} className="text-green-600 dark:text-green-400" />
                              ) : (
                                <X size={12} className="text-red-600 dark:text-red-400" />
                              )}
                            </span>
                            <span className="text-sm text-gray-600 dark:text-gray-400">
                              Class Rep Verified
                            </span>
                          </div>
                          
                          <div className="flex items-center">
                            <span className={`inline-flex items-center justify-center w-5 h-5 rounded-full mr-1.5 ${
                              mark.hodApproved ? 'bg-green-100 dark:bg-green-900/30' : 'bg-red-100 dark:bg-red-900/30'
                            }`}>
                              {mark.hodApproved ? (
                                <Check size={12} className="text-green-600 dark:text-green-400" />
                              ) : (
                                <X size={12} className="text-red-600 dark:text-red-400" />
                              )}
                            </span>
                            <span className="text-sm text-gray-600 dark:text-gray-400">
                              HoD Approved
                            </span>
                          </div>
                        </div>
                      </div>
                      
                      <div>
                        <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300">Current Status:</h4>
                        <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">
                          {mark.status === 'pending' 
                            ? 'Waiting for admin decision' 
                            : mark.status === 'approved'
                              ? `Approved by ${mark.reviewedBy}`
                              : `Rejected by ${mark.reviewedBy}`}
                        </p>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                      <div>
                        <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300">Parent Contact:</h4>
                        <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">{mark.parentContact}</p>
                        <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">
                          {mark.parentNotified 
                            ? 'Parents have been notified about this incident.' 
                            : 'Parents have not been notified yet.'}
                        </p>
                      </div>
                      
                      <div>
                        <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300">Black Mark Count:</h4>
                        <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">
                          This student has <span className="font-medium">{mark.blackMarkCount} of 5</span> black marks in this semester
                        </p>
                      </div>
                    </div>
                    
                    {mark.studentResponse && (
                      <div className="mb-4">
                        <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300">Student Response:</h4>
                        <p className="mt-1 text-sm text-gray-600 dark:text-gray-400 italic">"{mark.studentResponse}"</p>
                      </div>
                    )}
                    
                    {/* Admin actions */}
                    <div className="mt-4 border-t border-gray-200 dark:border-gray-700 pt-4 flex flex-wrap gap-2">
                      {mark.status === 'pending' && (
                        <>
                          <button
                            onClick={() => handleApproveBlackMark(mark.id)}
                            className="inline-flex items-center px-3 py-1.5 border border-transparent text-sm leading-4 font-medium rounded-md shadow-sm text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
                          >
                            <CheckCircle size={16} className="mr-1" />
                            Approve
                          </button>
                          <button
                            onClick={() => handleRejectBlackMark(mark.id)}
                            className="inline-flex items-center px-3 py-1.5 border border-transparent text-sm leading-4 font-medium rounded-md shadow-sm text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
                          >
                            <XCircle size={16} className="mr-1" />
                            Reject
                          </button>
                        </>
                      )}
                      
                      {mark.status === 'approved' && !mark.parentNotified && (
                        <button
                          onClick={() => handleNotifyParent(mark.id)}
                          className="inline-flex items-center px-3 py-1.5 border border-transparent text-sm leading-4 font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                        >
                          <Users size={16} className="mr-1" />
                          Notify Parent
                        </button>
                      )}
                      
                      {/* Override option always available for admin */}
                      <button
                        onClick={() => {
                          addNotification({
                            type: 'warning',
                            title: 'Black Mark Overridden',
                            message: `Black mark for ${mark.studentName} has been overridden by admin.`,
                          });
                        }}
                        className="inline-flex items-center px-3 py-1.5 border border-gray-300 dark:border-gray-600 text-sm leading-4 font-medium rounded-md shadow-sm text-gray-700 dark:text-gray-200 bg-white dark:bg-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                      >
                        Override
                      </button>
                    </div>
                  </div>
                )}
              </li>
            ))}
          </ul>
        )}
      </div>

      {/* Information Box */}
      <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
        <div className="flex">
          <div className="flex-shrink-0">
            <AlertCircle className="h-5 w-5 text-blue-400" aria-hidden="true" />
          </div>
          <div className="ml-3 flex-1 md:flex md:justify-between">
            <p className="text-sm text-blue-700 dark:text-blue-300">
              Admins have full control over black marks and can approve, reject, or override any decisions. Remember that the system uses a fair evaluation process with context awareness.
            </p>
            <p className="mt-3 text-sm md:mt-0 md:ml-6">
              <a href="#" className="whitespace-nowrap font-medium text-blue-700 dark:text-blue-300 hover:text-blue-600 dark:hover:text-blue-200">
                View Black Mark Policy →
              </a>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminBlackMarks;