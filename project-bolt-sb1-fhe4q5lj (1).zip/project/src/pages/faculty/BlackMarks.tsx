import React, { useState } from 'react';
import { 
  AlertTriangle, Search, Filter, Plus, Users, X, 
  Check, ChevronDown, ChevronUp, AlertCircle 
} from 'lucide-react';
import { useNotifications } from '../../contexts/NotificationContext';

// Mock data for students
const students = [
  { id: 1, name: 'John Smith', rollNumber: 'S20210001', program: 'Computer Science', year: 2 },
  { id: 2, name: 'Emily Johnson', rollNumber: 'S20210002', program: 'Physics', year: 2 },
  { id: 3, name: 'Michael Brown', rollNumber: 'S20210003', program: 'Mathematics', year: 2 },
  { id: 4, name: 'Sarah Williams', rollNumber: 'S20210004', program: 'English Literature', year: 2 },
  { id: 5, name: 'David Jones', rollNumber: 'S20210005', program: 'Chemistry', year: 2 },
];

// Mock data for black marks (issued by this faculty)
const blackMarks = [
  { 
    id: 1, 
    studentId: 1, 
    studentName: 'John Smith',
    reason: 'Late to class', 
    date: '2025-05-10', 
    severity: 'low',
    subject: 'Database Systems',
    details: 'Arrived 15 minutes late to class without prior notification.',
    status: 'pending', // 'pending', 'approved', 'rejected'
    reviewedBy: null,
    parentNotified: true,
    studentResponse: null
  },
  { 
    id: 2, 
    studentId: 2, 
    studentName: 'Emily Johnson',
    reason: 'Missing assignment', 
    date: '2025-05-01', 
    severity: 'medium',
    subject: 'Algorithm Analysis',
    details: 'Failed to submit the assignment by the deadline without requesting an extension.',
    status: 'approved',
    reviewedBy: 'Prof. Anderson (HoD)',
    parentNotified: true,
    studentResponse: 'I was sick and forgot to inform you. Sorry.'
  },
  { 
    id: 3, 
    studentId: 3, 
    studentName: 'Michael Brown',
    reason: 'Disruptive behavior', 
    date: '2025-04-15', 
    severity: 'high',
    subject: 'Operating Systems',
    details: 'Repeatedly talking and disrupting the class during a lecture despite warnings.',
    status: 'rejected',
    reviewedBy: 'Prof. Anderson (HoD)',
    parentNotified: false,
    studentResponse: 'I apologize for my behavior. It won\'t happen again.'
  },
];

// Common black mark reasons for quick selection
const commonReasons = [
  'Late to class',
  'Missing assignment',
  'Disruptive behavior',
  'Unauthorized device usage',
  'Absent without leave',
  'Plagiarism',
  'Improper conduct',
  'Dress code violation'
];

const FacultyBlackMarks: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filter, setFilter] = useState('all'); // 'all', 'pending', 'approved', 'rejected'
  const [sortBy, setSortBy] = useState('date'); // 'date', 'severity', 'student'
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [expandedId, setExpandedId] = useState<number | null>(null);
  const { addNotification } = useNotifications();
  
  // Form state for new black mark
  const [newBlackMark, setNewBlackMark] = useState({
    studentId: '',
    reason: '',
    severity: 'low',
    subject: '',
    details: '',
    customReason: '',
  });

  const toggleExpand = (id: number) => {
    if (expandedId === id) {
      setExpandedId(null);
    } else {
      setExpandedId(id);
    }
  };

  const filteredBlackMarks = blackMarks
    .filter(mark => {
      // Filter by status
      if (filter !== 'all' && mark.status !== filter) return false;
      
      // Filter by search term
      const searchText = (
        mark.studentName + 
        mark.reason + 
        mark.subject
      ).toLowerCase();
      
      return searchText.includes(searchTerm.toLowerCase());
    })
    .sort((a, b) => {
      // Sort by selected criterion
      if (sortBy === 'date') {
        return new Date(b.date).getTime() - new Date(a.date).getTime();
      } else if (sortBy === 'severity') {
        const severityOrder = { low: 1, medium: 2, high: 3 };
        return severityOrder[b.severity as keyof typeof severityOrder] - 
               severityOrder[a.severity as keyof typeof severityOrder];
      } else if (sortBy === 'student') {
        return a.studentName.localeCompare(b.studentName);
      }
      return 0;
    });

  const handleSubmitBlackMark = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Create new black mark logic (would involve API calls in a real app)
    console.log('Submitting new black mark:', newBlackMark);
    
    // Close modal and reset form
    setIsModalOpen(false);
    setNewBlackMark({
      studentId: '',
      reason: '',
      severity: 'low',
      subject: '',
      details: '',
      customReason: '',
    });
    
    // Show notification
    addNotification({
      type: 'success',
      title: 'Black Mark Created',
      message: 'Black mark has been submitted for approval by HoD.',
    });
  };

  const getStatusClass = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-400';
      case 'approved':
        return 'bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-400';
      case 'rejected':
        return 'bg-red-100 dark:bg-red-900/30 text-red-800 dark:text-red-400';
      default:
        return 'bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-400';
    }
  };

  const getSeverityClass = (severity: string) => {
    switch (severity) {
      case 'low':
        return 'bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-400';
      case 'medium':
        return 'bg-orange-100 dark:bg-orange-900/30 text-orange-800 dark:text-orange-400';
      case 'high':
        return 'bg-red-100 dark:bg-red-900/30 text-red-800 dark:text-red-400';
      default:
        return 'bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-400';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-800 dark:text-white flex items-center">
              <AlertTriangle className="mr-2 text-yellow-500" size={24} />
              Black Marks Management
            </h1>
            <p className="text-gray-600 dark:text-gray-400 mt-1">
              Issue and manage student black marks for disciplinary actions
            </p>
          </div>
          
          <div className="mt-4 md:mt-0">
            <button
              onClick={() => setIsModalOpen(true)}
              className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              <Plus size={16} className="mr-2" />
              Issue New Black Mark
            </button>
          </div>
        </div>
      </div>

      {/* Filters and Search */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4">
        <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-4">
          <div className="relative flex-1">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search size={18} className="text-gray-400" />
            </div>
            <input
              type="text"
              className="block w-full pl-10 pr-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md leading-5 bg-white dark:bg-gray-700 placeholder-gray-500 focus:outline-none focus:ring-blue-500 focus:border-blue-500 text-gray-900 dark:text-white sm:text-sm"
              placeholder="Search by student or reason..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <div className="flex space-x-4">
            <select
              className="block w-full pl-3 pr-10 py-2 text-base border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
            >
              <option value="all">All Statuses</option>
              <option value="pending">Pending</option>
              <option value="approved">Approved</option>
              <option value="rejected">Rejected</option>
            </select>
            
            <select
              className="block w-full pl-3 pr-10 py-2 text-base border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
            >
              <option value="date">Sort by Date</option>
              <option value="severity">Sort by Severity</option>
              <option value="student">Sort by Student</option>
            </select>
          </div>
        </div>
      </div>

      {/* Black Marks List */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow">
        {filteredBlackMarks.length === 0 ? (
          <div className="p-6 text-center">
            <AlertCircle size={48} className="mx-auto mb-4 text-gray-400" />
            <h3 className="text-lg font-medium text-gray-800 dark:text-white">No black marks found</h3>
            <p className="text-gray-600 dark:text-gray-400 mt-1">
              {searchTerm 
                ? 'No results match your search criteria' 
                : 'You haven\'t issued any black marks yet'}
            </p>
          </div>
        ) : (
          <ul className="divide-y divide-gray-200 dark:divide-gray-700">
            {filteredBlackMarks.map((mark) => (
              <li key={mark.id} className="p-4 hover:bg-gray-50 dark:hover:bg-gray-750">
                <div 
                  className="flex justify-between items-start cursor-pointer"
                  onClick={() => toggleExpand(mark.id)}
                >
                  <div className="flex items-start">
                    <div className={`p-2 rounded-full mr-4 ${getSeverityClass(mark.severity)}`}>
                      <AlertTriangle size={20} />
                    </div>
                    <div>
                      <h3 className="font-medium text-gray-800 dark:text-white">{mark.reason}</h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        Student: {mark.studentName} • {mark.subject}
                      </p>
                      <p className="text-sm text-gray-500 dark:text-gray-500">
                        {new Date(mark.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium capitalize mr-2 ${getStatusClass(mark.status)}`}>
                      {mark.status}
                    </span>
                    {expandedId === mark.id ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
                  </div>
                </div>
                
                {/* Expanded details */}
                {expandedId === mark.id && (
                  <div className="mt-4 pl-12 border-t border-gray-200 dark:border-gray-700 pt-4">
                    <div className="mb-3">
                      <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300">Details:</h4>
                      <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">{mark.details}</p>
                    </div>
                    
                    <div className="mb-3">
                      <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300">Status:</h4>
                      <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">
                        {mark.status === 'pending' 
                          ? 'Waiting for HoD approval' 
                          : mark.status === 'approved'
                            ? `Approved by ${mark.reviewedBy}`
                            : `Rejected by ${mark.reviewedBy}`}
                      </p>
                    </div>
                    
                    <div className="mb-3">
                      <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300">Parent Notification:</h4>
                      <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">
                        {mark.parentNotified 
                          ? 'Parents have been notified about this incident.' 
                          : 'Parents have not been notified yet.'}
                      </p>
                    </div>
                    
                    {mark.studentResponse && (
                      <div>
                        <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300">Student Response:</h4>
                        <p className="mt-1 text-sm text-gray-600 dark:text-gray-400 italic">"{mark.studentResponse}"</p>
                      </div>
                    )}
                  </div>
                )}
              </li>
            ))}
          </ul>
        )}
      </div>

      {/* New Black Mark Modal */}
      {isModalOpen && (
        <div className="fixed z-10 inset-0 overflow-y-auto">
          <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            {/* Background overlay */}
            <div className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" onClick={() => setIsModalOpen(false)}></div>

            {/* Modal panel */}
            <div className="inline-block align-bottom bg-white dark:bg-gray-800 rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
              <div className="px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                <div className="sm:flex sm:items-start">
                  <div className="mx-auto flex-shrink-0 flex items-center justify-center h-12 w-12 rounded-full bg-yellow-100 dark:bg-yellow-900/30 sm:mx-0 sm:h-10 sm:w-10">
                    <AlertTriangle className="h-6 w-6 text-yellow-600 dark:text-yellow-400" />
                  </div>
                  <div className="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left">
                    <h3 className="text-lg leading-6 font-medium text-gray-900 dark:text-white">
                      Issue New Black Mark
                    </h3>
                    <div className="mt-2">
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        Please provide the details for the new black mark. This will be sent to the HoD for approval.
                      </p>
                    </div>
                  </div>
                </div>
                
                <form onSubmit={handleSubmitBlackMark} className="mt-5">
                  <div className="space-y-4">
                    {/* Student selection */}
                    <div>
                      <label htmlFor="student" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                        Student
                      </label>
                      <select
                        id="student"
                        className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                        value={newBlackMark.studentId}
                        onChange={(e) => setNewBlackMark({...newBlackMark, studentId: e.target.value})}
                        required
                      >
                        <option value="">Select a student</option>
                        {students.map(student => (
                          <option key={student.id} value={student.id}>
                            {student.name} ({student.rollNumber})
                          </option>
                        ))}
                      </select>
                    </div>
                    
                    {/* Subject */}
                    <div>
                      <label htmlFor="subject" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                        Subject
                      </label>
                      <input
                        type="text"
                        id="subject"
                        className="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                        placeholder="E.g., Database Systems"
                        value={newBlackMark.subject}
                        onChange={(e) => setNewBlackMark({...newBlackMark, subject: e.target.value})}
                        required
                      />
                    </div>
                    
                    {/* Reason */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                        Reason
                      </label>
                      <div className="mt-1 grid grid-cols-2 gap-2">
                        {commonReasons.map((reason, index) => (
                          <button
                            key={index}
                            type="button"
                            className={`py-2 px-3 text-sm border rounded-md text-left ${
                              newBlackMark.reason === reason
                                ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300'
                                : 'border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-300'
                            }`}
                            onClick={() => setNewBlackMark({...newBlackMark, reason})}
                          >
                            {reason}
                          </button>
                        ))}
                      </div>
                      <div className="mt-2">
                        <input
                          type="text"
                          className="block w-full border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                          placeholder="Or enter a custom reason..."
                          value={newBlackMark.customReason}
                          onChange={(e) => {
                            setNewBlackMark({
                              ...newBlackMark, 
                              customReason: e.target.value,
                              reason: e.target.value ? e.target.value : newBlackMark.reason
                            });
                          }}
                        />
                      </div>
                    </div>
                    
                    {/* Severity */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                        Severity
                      </label>
                      <div className="mt-1 flex space-x-2">
                        <button
                          type="button"
                          className={`flex-1 py-2 px-3 rounded-md text-center ${
                            newBlackMark.severity === 'low'
                              ? 'bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-300 border border-yellow-300 dark:border-yellow-800'
                              : 'bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-300 border border-gray-300 dark:border-gray-600'
                          }`}
                          onClick={() => setNewBlackMark({...newBlackMark, severity: 'low'})}
                        >
                          Low
                        </button>
                        <button
                          type="button"
                          className={`flex-1 py-2 px-3 rounded-md text-center ${
                            newBlackMark.severity === 'medium'
                              ? 'bg-orange-100 dark:bg-orange-900/30 text-orange-800 dark:text-orange-300 border border-orange-300 dark:border-orange-800'
                              : 'bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-300 border border-gray-300 dark:border-gray-600'
                          }`}
                          onClick={() => setNewBlackMark({...newBlackMark, severity: 'medium'})}
                        >
                          Medium
                        </button>
                        <button
                          type="button"
                          className={`flex-1 py-2 px-3 rounded-md text-center ${
                            newBlackMark.severity === 'high'
                              ? 'bg-red-100 dark:bg-red-900/30 text-red-800 dark:text-red-300 border border-red-300 dark:border-red-800'
                              : 'bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-300 border border-gray-300 dark:border-gray-600'
                          }`}
                          onClick={() => setNewBlackMark({...newBlackMark, severity: 'high'})}
                        >
                          High
                        </button>
                      </div>
                    </div>
                    
                    {/* Details */}
                    <div>
                      <label htmlFor="details" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                        Detailed Description
                      </label>
                      <textarea
                        id="details"
                        rows={3}
                        className="mt-1 block w-full border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                        placeholder="Provide detailed description of the incident..."
                        value={newBlackMark.details}
                        onChange={(e) => setNewBlackMark({...newBlackMark, details: e.target.value})}
                        required
                      />
                    </div>
                  </div>
                  
                  <div className="mt-5 sm:mt-6 sm:grid sm:grid-cols-2 sm:gap-3 sm:grid-flow-row-dense">
                    <button
                      type="submit"
                      className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-blue-600 text-base font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:col-start-2 sm:text-sm"
                    >
                      Submit for Approval
                    </button>
                    <button
                      type="button"
                      className="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 dark:border-gray-600 shadow-sm px-4 py-2 bg-white dark:bg-gray-700 text-base font-medium text-gray-700 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:mt-0 sm:col-start-1 sm:text-sm"
                      onClick={() => setIsModalOpen(false)}
                    >
                      Cancel
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Information Box */}
      <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
        <div className="flex">
          <div className="flex-shrink-0">
            <AlertCircle className="h-5 w-5 text-blue-400" aria-hidden="true" />
          </div>
          <div className="ml-3 flex-1 md:flex md:justify-between">
            <p className="text-sm text-blue-700 dark:text-blue-300">
              All black marks require approval from the Head of Department before they are applied to a student's record.
            </p>
            <p className="mt-3 text-sm md:mt-0 md:ml-6">
              <a href="#" className="whitespace-nowrap font-medium text-blue-700 dark:text-blue-300 hover:text-blue-600 dark:hover:text-blue-200">
                View Discipline Policy →
              </a>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FacultyBlackMarks;