import React from 'react';

const FacultyDashboard = () => {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
        Faculty Dashboard
      </h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
            Classes Today
          </h2>
          <p className="text-gray-600 dark:text-gray-300">
            No classes scheduled for today
          </p>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
            Recent Feedback
          </h2>
          <p className="text-gray-600 dark:text-gray-300">
            No recent feedback
          </p>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
            Student Reports
          </h2>
          <p className="text-gray-600 dark:text-gray-300">
            No pending reports
          </p>
        </div>
      </div>
    </div>
  );
};

export default FacultyDashboard;