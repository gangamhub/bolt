import React, { useState } from 'react';
import { AlertTriangle, Filter, AlertCircle, ChevronDown, ChevronUp } from 'lucide-react';

// Mock data for student black marks
const studentBlackMarks = [
  { 
    id: 1, 
    reason: 'Late to class', 
    date: '2025-05-10', 
    severity: 'low',
    assignedBy: 'Dr. Smith',
    subject: 'Mathematics',
    details: 'Arrived 15 minutes late to class without prior notification.',
    response: null,
    parentNotified: true
  },
  { 
    id: 2, 
    reason: 'Missing assignment', 
    date: '2025-05-01', 
    severity: 'medium',
    assignedBy: 'Prof. Johnson',
    subject: 'Physics',
    details: 'Failed to submit the lab report by the deadline without requesting an extension.',
    response: 'I was sick and forgot to inform you. Sorry.',
    parentNotified: true
  },
  { 
    id: 3, 
    reason: 'Disruptive behavior', 
    date: '2025-04-15', 
    severity: 'high',
    assignedBy: 'Dr. Williams',
    subject: 'Computer Science',
    details: 'Repeatedly talking and disrupting the class during a lecture despite warnings.',
    response: 'I apologize for my behavior. It won\'t happen again.',
    parentNotified: true
  },
  { 
    id: 4, 
    reason: 'Unauthorized device usage', 
    date: '2025-04-05', 
    severity: 'medium',
    assignedBy: 'Prof. Davis',
    subject: 'English Literature',
    details: 'Using phone during exam despite clear instructions against electronic devices.',
    response: 'I was checking the time and forgot to put my phone away.',
    parentNotified: true
  },
];

const BlackMarks: React.FC = () => {
  const [filter, setFilter] = useState('all'); // 'all', 'low', 'medium', 'high'
  const [expandedId, setExpandedId] = useState<number | null>(null);

  const toggleExpand = (id: number) => {
    if (expandedId === id) {
      setExpandedId(null);
    } else {
      setExpandedId(id);
    }
  };

  const filteredMarks = studentBlackMarks.filter(mark => {
    if (filter === 'all') return true;
    return mark.severity === filter;
  });

  const getSeverityClass = (severity: string) => {
    switch (severity) {
      case 'low':
        return 'bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-400';
      case 'medium':
        return 'bg-orange-100 dark:bg-orange-900/30 text-orange-800 dark:text-orange-400';
      case 'high':
        return 'bg-red-100 dark:bg-red-900/30 text-red-800 dark:text-red-400';
      default:
        return 'bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-400';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-800 dark:text-white flex items-center">
              <AlertTriangle className="mr-2 text-yellow-500" size={24} />
              Black Marks History
            </h1>
            <p className="text-gray-600 dark:text-gray-400 mt-1">
              View and respond to your black marks. Accumulated: {studentBlackMarks.length} of 5 limit
            </p>
          </div>
          
          <div className="mt-4 md:mt-0 flex items-center">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Filter size={16} className="text-gray-500" />
              </div>
              <select
                className="pl-10 pr-10 py-2 border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 text-gray-700 dark:text-white"
                value={filter}
                onChange={(e) => setFilter(e.target.value)}
              >
                <option value="all">All Severities</option>
                <option value="low">Low</option>
                <option value="medium">Medium</option>
                <option value="high">High</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Black Marks List */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow">
        {filteredMarks.length === 0 ? (
          <div className="p-6 text-center">
            <AlertCircle size={48} className="mx-auto mb-4 text-gray-400" />
            <h3 className="text-lg font-medium text-gray-800 dark:text-white">No black marks found</h3>
            <p className="text-gray-600 dark:text-gray-400 mt-1">
              {filter === 'all' 
                ? 'You have no black marks on record. Keep up the good work!' 
                : `You have no ${filter} severity black marks.`}
            </p>
          </div>
        ) : (
          <ul className="divide-y divide-gray-200 dark:divide-gray-700">
            {filteredMarks.map((mark) => (
              <li key={mark.id} className="p-4 hover:bg-gray-50 dark:hover:bg-gray-750">
                <div 
                  className="flex justify-between items-start cursor-pointer"
                  onClick={() => toggleExpand(mark.id)}
                >
                  <div className="flex items-start">
                    <div className={`p-2 rounded-full mr-4 ${getSeverityClass(mark.severity)}`}>
                      <AlertTriangle size={20} />
                    </div>
                    <div>
                      <h3 className="font-medium text-gray-800 dark:text-white">{mark.reason}</h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        {new Date(mark.date).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
                      </p>
                      <p className="text-sm text-gray-500 dark:text-gray-500">{mark.subject} • {mark.assignedBy}</p>
                    </div>
                  </div>
                  <div className="flex items-center">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium capitalize mr-2 ${getSeverityClass(mark.severity)}`}>
                      {mark.severity}
                    </span>
                    {expandedId === mark.id ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
                  </div>
                </div>
                
                {/* Expanded details */}
                {expandedId === mark.id && (
                  <div className="mt-4 pl-12 border-t border-gray-200 dark:border-gray-700 pt-4">
                    <div className="mb-3">
                      <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300">Details:</h4>
                      <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">{mark.details}</p>
                    </div>
                    
                    <div className="mb-3">
                      <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300">Parent Notification:</h4>
                      <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">
                        {mark.parentNotified 
                          ? 'Parents have been notified about this incident.' 
                          : 'Parents have not been notified yet.'}
                      </p>
                    </div>
                    
                    <div>
                      <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300">Your Response:</h4>
                      {mark.response ? (
                        <p className="mt-1 text-sm text-gray-600 dark:text-gray-400 italic">"{mark.response}"</p>
                      ) : (
                        <div className="mt-2">
                          <textarea
                            className="w-full px-3 py-2 text-gray-700 dark:text-white border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600"
                            rows={3}
                            placeholder="Provide your response or explanation here..."
                          ></textarea>
                          <button className="mt-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2">
                            Submit Response
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </li>
            ))}
          </ul>
        )}
      </div>

      {/* Information Box */}
      <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
        <div className="flex">
          <div className="flex-shrink-0">
            <AlertCircle className="h-5 w-5 text-blue-400" aria-hidden="true" />
          </div>
          <div className="ml-3 flex-1 md:flex md:justify-between">
            <p className="text-sm text-blue-700 dark:text-blue-300">
              Black marks are issued for behavioral or academic violations. If you receive 5 black marks in a semester, you may face disciplinary action.
            </p>
            <p className="mt-3 text-sm md:mt-0 md:ml-6">
              <a href="#" className="whitespace-nowrap font-medium text-blue-700 dark:text-blue-300 hover:text-blue-600 dark:hover:text-blue-200">
                View Discipline Policy →
              </a>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BlackMarks;