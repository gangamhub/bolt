import React from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  AlertTriangle, BookOpen, Calendar, Trophy, Smile, 
  GraduationCap, Award, Clock, FileText
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

// Mock data for student dashboard
const blackMarks = [
  { id: 1, reason: 'Late to class', date: '2025-05-10', severity: 'low' },
  { id: 2, reason: 'Missing assignment', date: '2025-05-01', severity: 'medium' },
];

const upcomingEvents = [
  { id: 1, title: 'Tech Talk: AI in Education', date: '2025-05-15', time: '14:00' },
  { id: 2, title: 'Basketball Tournament', date: '2025-05-17', time: '10:00' },
  { id: 3, title: 'Coding Competition', date: '2025-05-20', time: '09:00' },
];

const upcomingClasses = [
  { id: 1, subject: 'Mathematics', time: '09:00 - 10:30', room: 'R201', teacher: 'Dr. Smith' },
  { id: 2, subject: 'Physics', time: '11:00 - 12:30', room: 'R105', teacher: 'Prof. Johnson' },
  { id: 3, subject: 'Computer Science', time: '14:00 - 15:30', room: 'Lab 3', teacher: 'Dr. Williams' },
];

const recentFeedback = [
  { id: 1, subject: 'Mathematics Assignment', comment: 'Excellent work, well explained solutions', grade: 'A', date: '2025-05-05' },
  { id: 2, subject: 'Physics Lab Report', comment: 'Good analysis but lacks proper conclusion', grade: 'B+', date: '2025-05-03' },
];

const semesterProgress = [
  { subject: 'Mathematics', progress: 67 },
  { subject: 'Physics', progress: 58 },
  { subject: 'Computer Science', progress: 72 },
  { subject: 'English Literature', progress: 85 },
];

const disciplinePoints = 450; // Out of 500
const pointsPercentage = (disciplinePoints / 500) * 100;
const pointsColor = pointsPercentage > 80 ? 'text-green-500' : pointsPercentage > 60 ? 'text-yellow-500' : 'text-red-500';

const StudentDashboard: React.FC = () => {
  const { currentUser } = useAuth();
  const navigate = useNavigate();

  // Get current date
  const today = new Date();
  const formattedDate = today.toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  return (
    <div className="space-y-6">
      {/* Welcome header */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
        <h1 className="text-2xl font-bold text-gray-800 dark:text-white">
          Welcome back, {currentUser?.name}!
        </h1>
        <p className="text-gray-600 dark:text-gray-300 mt-1">{formattedDate}</p>
        
        <div className="mt-4 grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4 flex items-center">
            <div className="bg-blue-500 text-white p-3 rounded-full mr-4">
              <GraduationCap size={20} />
            </div>
            <div>
              <p className="text-gray-500 dark:text-gray-400 text-sm">Semester</p>
              <p className="text-gray-800 dark:text-white font-medium">Spring 2025</p>
            </div>
          </div>
          
          <div className="bg-yellow-50 dark:bg-yellow-900/20 rounded-lg p-4 flex items-center">
            <div className="bg-yellow-500 text-white p-3 rounded-full mr-4">
              <AlertTriangle size={20} />
            </div>
            <div>
              <p className="text-gray-500 dark:text-gray-400 text-sm">Black Marks</p>
              <p className="text-gray-800 dark:text-white font-medium">2 of 5 limit</p>
            </div>
          </div>
          
          <div className="bg-green-50 dark:bg-green-900/20 rounded-lg p-4 flex items-center">
            <div className="bg-green-500 text-white p-3 rounded-full mr-4">
              <Award size={20} />
            </div>
            <div>
              <p className="text-gray-500 dark:text-gray-400 text-sm">Discipline Points</p>
              <p className={`font-medium ${pointsColor}`}>{disciplinePoints}/500</p>
            </div>
          </div>
          
          <div className="bg-purple-50 dark:bg-purple-900/20 rounded-lg p-4 flex items-center">
            <div className="bg-purple-500 text-white p-3 rounded-full mr-4">
              <Clock size={20} />
            </div>
            <div>
              <p className="text-gray-500 dark:text-gray-400 text-sm">Attendance</p>
              <p className="text-gray-800 dark:text-white font-medium">95%</p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Main dashboard content */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Today's Classes */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow">
          <div className="p-4 border-b border-gray-200 dark:border-gray-700 flex justify-between items-center">
            <h2 className="text-lg font-medium text-gray-800 dark:text-white flex items-center">
              <Calendar size={18} className="mr-2 text-blue-500" />
              Today's Classes
            </h2>
            <button
              onClick={() => navigate('/dashboard/student/timetable')}
              className="text-sm text-blue-600 dark:text-blue-400 hover:underline"
            >
              View All
            </button>
          </div>
          
          <div className="p-4">
            <div className="space-y-4">
              {upcomingClasses.map((cls) => (
                <div key={cls.id} className="flex items-start">
                  <div className="bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 p-2 rounded mr-3">
                    <BookOpen size={18} />
                  </div>
                  <div>
                    <h3 className="font-medium text-gray-800 dark:text-white">{cls.subject}</h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400">{cls.time} • Room {cls.room}</p>
                    <p className="text-sm text-gray-500 dark:text-gray-500">{cls.teacher}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
        
        {/* Upcoming Events */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow">
          <div className="p-4 border-b border-gray-200 dark:border-gray-700 flex justify-between items-center">
            <h2 className="text-lg font-medium text-gray-800 dark:text-white flex items-center">
              <Award size={18} className="mr-2 text-purple-500" />
              Upcoming Events
            </h2>
            <button
              onClick={() => navigate('/dashboard/student/events')}
              className="text-sm text-blue-600 dark:text-blue-400 hover:underline"
            >
              View All
            </button>
          </div>
          
          <div className="p-4">
            <div className="space-y-4">
              {upcomingEvents.map((event) => (
                <div key={event.id} className="flex items-start">
                  <div className="bg-purple-100 dark:bg-purple-900/30 text-purple-600 dark:text-purple-400 p-2 rounded mr-3">
                    <Calendar size={18} />
                  </div>
                  <div>
                    <h3 className="font-medium text-gray-800 dark:text-white">{event.title}</h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      {new Date(event.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} • {event.time}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
        
        {/* Black Marks */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow">
          <div className="p-4 border-b border-gray-200 dark:border-gray-700 flex justify-between items-center">
            <h2 className="text-lg font-medium text-gray-800 dark:text-white flex items-center">
              <AlertTriangle size={18} className="mr-2 text-yellow-500" />
              Recent Black Marks
            </h2>
            <button
              onClick={() => navigate('/dashboard/student/black-marks')}
              className="text-sm text-blue-600 dark:text-blue-400 hover:underline"
            >
              View All
            </button>
          </div>
          
          <div className="p-4">
            {blackMarks.length === 0 ? (
              <p className="text-gray-500 dark:text-gray-400 text-center py-4">No black marks yet. Keep it up!</p>
            ) : (
              <div className="space-y-4">
                {blackMarks.map((mark) => (
                  <div key={mark.id} className="flex items-start">
                    <div className={`
                      p-2 rounded mr-3
                      ${mark.severity === 'low' ? 'bg-yellow-100 dark:bg-yellow-900/30 text-yellow-600 dark:text-yellow-400' : 
                        mark.severity === 'medium' ? 'bg-orange-100 dark:bg-orange-900/30 text-orange-600 dark:text-orange-400' : 
                        'bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400'}
                    `}>
                      <AlertTriangle size={18} />
                    </div>
                    <div>
                      <h3 className="font-medium text-gray-800 dark:text-white">{mark.reason}</h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        {new Date(mark.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                      </p>
                      <p className="text-sm capitalize text-gray-500 dark:text-gray-500">
                        Severity: {mark.severity}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
      
      {/* Syllabus Progress and Recent Feedback */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Syllabus Progress */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow">
          <div className="p-4 border-b border-gray-200 dark:border-gray-700 flex justify-between items-center">
            <h2 className="text-lg font-medium text-gray-800 dark:text-white flex items-center">
              <BookOpen size={18} className="mr-2 text-green-500" />
              Syllabus Progress
            </h2>
            <button
              onClick={() => navigate('/dashboard/student/syllabus')}
              className="text-sm text-blue-600 dark:text-blue-400 hover:underline"
            >
              View Details
            </button>
          </div>
          
          <div className="p-4">
            <div className="space-y-4">
              {semesterProgress.map((subject, index) => (
                <div key={index}>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm font-medium text-gray-700 dark:text-gray-300">{subject.subject}</span>
                    <span className="text-sm font-medium text-gray-700 dark:text-gray-300">{subject.progress}%</span>
                  </div>
                  <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                    <div 
                      className="bg-green-500 h-2 rounded-full" 
                      style={{ width: `${subject.progress}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
        
        {/* Recent Feedback */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow">
          <div className="p-4 border-b border-gray-200 dark:border-gray-700 flex justify-between items-center">
            <h2 className="text-lg font-medium text-gray-800 dark:text-white flex items-center">
              <FileText size={18} className="mr-2 text-indigo-500" />
              Recent Results
            </h2>
            <button
              onClick={() => navigate('/dashboard/student/results')}
              className="text-sm text-blue-600 dark:text-blue-400 hover:underline"
            >
              View All
            </button>
          </div>
          
          <div className="p-4">
            <div className="space-y-4">
              {recentFeedback.map((feedback) => (
                <div key={feedback.id} className="flex items-start">
                  <div className="bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 p-2 rounded mr-3">
                    <FileText size={18} />
                  </div>
                  <div className="flex-1">
                    <div className="flex justify-between">
                      <h3 className="font-medium text-gray-800 dark:text-white">{feedback.subject}</h3>
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-400">
                        {feedback.grade}
                      </span>
                    </div>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">{feedback.comment}</p>
                    <p className="text-xs text-gray-500 dark:text-gray-500 mt-1">
                      {new Date(feedback.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StudentDashboard;