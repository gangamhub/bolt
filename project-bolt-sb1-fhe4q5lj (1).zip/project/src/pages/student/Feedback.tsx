import React, { useState } from 'react';
import { 
  Smile, Send, Lock, ArrowRightCircle, Check, 
  MessageSquare, Info, AlertCircle 
} from 'lucide-react';
import { useNotifications } from '../../contexts/NotificationContext';

// Mock data for previous feedback
const previousFeedback = [
  { 
    id: 1, 
    type: 'faculty', 
    subject: 'Teaching Methods Improvement',
    targetName: 'Dr. Williams', 
    targetDepartment: 'Computer Science',
    course: 'Database Systems',
    date: '2025-05-01', 
    status: 'submitted', 
    isAnonymous: true,
    content: 'The professor needs to provide more practical examples during lectures. The theoretical content is good but difficult to apply without examples.'
  },
  { 
    id: 2, 
    type: 'general', 
    subject: 'Library Hours Extension',
    targetName: null, 
    targetDepartment: null,
    course: null,
    date: '2025-04-15', 
    status: 'addressed', 
    isAnonymous: false,
    content: 'The library closes too early during exam weeks. It would be helpful if it could stay open until midnight during that period.'
  },
  { 
    id: 3, 
    type: 'women', 
    subject: 'Uncomfortable Situation in Lab',
    targetName: null, 
    targetDepartment: 'Physics',
    course: 'Physics Lab',
    date: '2025-04-10', 
    status: 'under_review', 
    isAnonymous: true,
    content: 'I felt uncomfortable during the lab session when a group of male students made inappropriate comments. The lab assistant didn\'t address this.'
  },
];

// Faculty list for selection
const facultyList = [
  { id: 1, name: 'Dr. Williams', department: 'Computer Science' },
  { id: 2, name: 'Prof. Johnson', department: 'Physics' },
  { id: 3, name: 'Dr. Smith', department: 'Mathematics' },
  { id: 4, name: 'Prof. Davis', department: 'English Literature' },
  { id: 5, name: 'Dr. Wilson', department: 'Chemistry' },
];

const courses = [
  { id: 1, name: 'Database Systems', faculty: 'Dr. Williams' },
  { id: 2, name: 'Algorithm Analysis', faculty: 'Dr. Williams' },
  { id: 3, name: 'Quantum Mechanics', faculty: 'Prof. Johnson' },
  { id: 4, name: 'Optics', faculty: 'Prof. Johnson' },
  { id: 5, name: 'Calculus III', faculty: 'Dr. Smith' },
  { id: 6, name: 'Linear Algebra', faculty: 'Dr. Smith' },
  { id: 7, name: 'Modern Literature', faculty: 'Prof. Davis' },
  { id: 8, name: 'Creative Writing', faculty: 'Prof. Davis' },
  { id: 9, name: 'Organic Chemistry', faculty: 'Dr. Wilson' },
  { id: 10, name: 'Biochemistry', faculty: 'Dr. Wilson' },
];

const StudentFeedback: React.FC = () => {
  const [activeTab, setActiveTab] = useState('new'); // 'new', 'previous'
  const [feedbackType, setFeedbackType] = useState('faculty'); // 'faculty', 'general', 'women'
  const { addNotification } = useNotifications();
  
  // New feedback form state
  const [newFeedback, setNewFeedback] = useState({
    subject: '',
    faculty: '',
    course: '',
    content: '',
    isAnonymous: true,
  });
  
  const [formErrors, setFormErrors] = useState({
    subject: false,
    faculty: feedbackType === 'faculty' ? false : undefined,
    content: false,
  });

  const handleFeedbackTypeChange = (type: string) => {
    setFeedbackType(type);
    setNewFeedback({
      ...newFeedback,
      faculty: '',
      course: '',
    });
    setFormErrors({
      ...formErrors,
      faculty: type === 'faculty' ? false : undefined,
    });
  };

  const handleSubmitFeedback = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate form
    const errors = {
      subject: !newFeedback.subject,
      faculty: feedbackType === 'faculty' ? !newFeedback.faculty : undefined,
      content: !newFeedback.content,
    };
    
    setFormErrors(errors);
    
    if (errors.subject || (errors.faculty && feedbackType === 'faculty') || errors.content) {
      addNotification({
        type: 'error',
        title: 'Form Error',
        message: 'Please fill in all required fields.',
      });
      return;
    }
    
    // Submit feedback logic (would involve API calls in a real app)
    console.log('Submitting feedback:', newFeedback);
    
    // Show success notification
    addNotification({
      type: 'success',
      title: 'Feedback Submitted',
      message: 'Your feedback has been submitted successfully. Thank you for your input!',
    });
    
    // Reset form
    setNewFeedback({
      subject: '',
      faculty: '',
      course: '',
      content: '',
      isAnonymous: true,
    });
    
    // Switch to previous tab to show the submitted feedback
    setActiveTab('previous');
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'submitted':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-300">
            <MessageSquare size={12} className="mr-1" />
            Submitted
          </span>
        );
      case 'under_review':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-300">
            <Info size={12} className="mr-1" />
            Under Review
          </span>
        );
      case 'addressed':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-300">
            <Check size={12} className="mr-1" />
            Addressed
          </span>
        );
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-800 dark:text-white flex items-center">
              <Smile className="mr-2 text-green-500" size={24} />
              Anonymous Feedback
            </h1>
            <p className="text-gray-600 dark:text-gray-400 mt-1">
              Share your thoughts and concerns safely and anonymously
            </p>
          </div>
          
          <div className="mt-4 md:mt-0">
            <div className="flex rounded-md shadow-sm" role="group">
              <button
                type="button"
                className={`px-4 py-2 text-sm font-medium rounded-l-md ${
                  activeTab === 'new'
                    ? 'bg-blue-600 text-white'
                    : 'bg-white dark:bg-gray-700 text-gray-700 dark:text-white border border-gray-300 dark:border-gray-600'
                }`}
                onClick={() => setActiveTab('new')}
              >
                New Feedback
              </button>
              <button
                type="button"
                className={`px-4 py-2 text-sm font-medium rounded-r-md ${
                  activeTab === 'previous'
                    ? 'bg-blue-600 text-white'
                    : 'bg-white dark:bg-gray-700 text-gray-700 dark:text-white border border-r border-t border-b border-gray-300 dark:border-gray-600'
                }`}
                onClick={() => setActiveTab('previous')}
              >
                Previous Feedback
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* New Feedback Form */}
      {activeTab === 'new' && (
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow">
          <div className="p-6">
            <h2 className="text-lg font-medium text-gray-800 dark:text-white mb-4">
              Submit New Feedback
            </h2>
            
            {/* Feedback type selector */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Type of Feedback
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <button
                  type="button"
                  className={`p-4 border rounded-lg text-left transition-colors ${
                    feedbackType === 'faculty'
                      ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                      : 'border-gray-300 dark:border-gray-600 hover:border-blue-300'
                  }`}
                  onClick={() => handleFeedbackTypeChange('faculty')}
                >
                  <div className="flex items-center mb-2">
                    <div className={`p-2 rounded-full ${
                      feedbackType === 'faculty' 
                        ? 'bg-blue-100 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400' 
                        : 'bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-400'
                    }`}>
                      <Smile size={20} />
                    </div>
                    <h3 className={`ml-2 font-medium ${
                      feedbackType === 'faculty' 
                        ? 'text-blue-700 dark:text-blue-400' 
                        : 'text-gray-800 dark:text-white'
                    }`}>
                      Faculty Feedback
                    </h3>
                  </div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Provide feedback about a specific faculty member or course
                  </p>
                </button>
                
                <button
                  type="button"
                  className={`p-4 border rounded-lg text-left transition-colors ${
                    feedbackType === 'general'
                      ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                      : 'border-gray-300 dark:border-gray-600 hover:border-blue-300'
                  }`}
                  onClick={() => handleFeedbackTypeChange('general')}
                >
                  <div className="flex items-center mb-2">
                    <div className={`p-2 rounded-full ${
                      feedbackType === 'general' 
                        ? 'bg-blue-100 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400' 
                        : 'bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-400'
                    }`}>
                      <MessageSquare size={20} />
                    </div>
                    <h3 className={`ml-2 font-medium ${
                      feedbackType === 'general' 
                        ? 'text-blue-700 dark:text-blue-400' 
                        : 'text-gray-800 dark:text-white'
                    }`}>
                      General Feedback
                    </h3>
                  </div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Provide feedback about general college facilities or policies
                  </p>
                </button>
                
                <button
                  type="button"
                  className={`p-4 border rounded-lg text-left transition-colors ${
                    feedbackType === 'women'
                      ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                      : 'border-gray-300 dark:border-gray-600 hover:border-blue-300'
                  }`}
                  onClick={() => handleFeedbackTypeChange('women')}
                >
                  <div className="flex items-center mb-2">
                    <div className={`p-2 rounded-full ${
                      feedbackType === 'women' 
                        ? 'bg-blue-100 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400' 
                        : 'bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-400'
                    }`}>
                      <Lock size={20} />
                    </div>
                    <h3 className={`ml-2 font-medium ${
                      feedbackType === 'women' 
                        ? 'text-blue-700 dark:text-blue-400' 
                        : 'text-gray-800 dark:text-white'
                    }`}>
                      Women's Safety
                    </h3>
                  </div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Confidential channel for women students to report safety concerns
                  </p>
                </button>
              </div>
            </div>
            
            <form onSubmit={handleSubmitFeedback}>
              <div className="mb-4">
                <label htmlFor="subject" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Subject <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  id="subject"
                  className={`block w-full rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white ${
                    formErrors.subject ? 'border-red-300 dark:border-red-700 focus:ring-red-500 focus:border-red-500' : ''
                  }`}
                  value={newFeedback.subject}
                  onChange={(e) => setNewFeedback({...newFeedback, subject: e.target.value})}
                  placeholder="Brief subject of your feedback"
                />
                {formErrors.subject && (
                  <p className="mt-1 text-sm text-red-600 dark:text-red-400">
                    Subject is required
                  </p>
                )}
              </div>
              
              {/* Faculty and course selection (only for faculty feedback) */}
              {feedbackType === 'faculty' && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                  <div>
                    <label htmlFor="faculty" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Faculty <span className="text-red-500">*</span>
                    </label>
                    <select
                      id="faculty"
                      className={`block w-full rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white ${
                        formErrors.faculty ? 'border-red-300 dark:border-red-700 focus:ring-red-500 focus:border-red-500' : ''
                      }`}
                      value={newFeedback.faculty}
                      onChange={(e) => setNewFeedback({...newFeedback, faculty: e.target.value})}
                    >
                      <option value="">Select a faculty member</option>
                      {facultyList.map((faculty) => (
                        <option key={faculty.id} value={faculty.name}>
                          {faculty.name} ({faculty.department})
                        </option>
                      ))}
                    </select>
                    {formErrors.faculty && (
                      <p className="mt-1 text-sm text-red-600 dark:text-red-400">
                        Faculty is required
                      </p>
                    )}
                  </div>
                  
                  <div>
                    <label htmlFor="course" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Course (Optional)
                    </label>
                    <select
                      id="course"
                      className="block w-full rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                      value={newFeedback.course}
                      onChange={(e) => setNewFeedback({...newFeedback, course: e.target.value})}
                      disabled={!newFeedback.faculty}
                    >
                      <option value="">Select a course</option>
                      {courses
                        .filter(course => course.faculty === newFeedback.faculty)
                        .map((course) => (
                          <option key={course.id} value={course.name}>
                            {course.name}
                          </option>
                        ))}
                    </select>
                  </div>
                </div>
              )}
              
              {/* Feedback content */}
              <div className="mb-4">
                <label htmlFor="content" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Feedback Details <span className="text-red-500">*</span>
                </label>
                <textarea
                  id="content"
                  rows={6}
                  className={`block w-full rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white ${
                    formErrors.content ? 'border-red-300 dark:border-red-700 focus:ring-red-500 focus:border-red-500' : ''
                  }`}
                  value={newFeedback.content}
                  onChange={(e) => setNewFeedback({...newFeedback, content: e.target.value})}
                  placeholder={
                    feedbackType === 'faculty' 
                      ? 'Describe your experience with this faculty member or course...' 
                      : feedbackType === 'general'
                        ? 'Describe your suggestion or concern about the college...'
                        : 'Describe the situation and any safety concerns you have...'
                  }
                />
                {formErrors.content && (
                  <p className="mt-1 text-sm text-red-600 dark:text-red-400">
                    Feedback details are required
                  </p>
                )}
              </div>
              
              {/* Anonymous option */}
              <div className="flex items-center mb-6">
                <input
                  id="anonymous"
                  type="checkbox"
                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                  checked={newFeedback.isAnonymous}
                  onChange={(e) => setNewFeedback({...newFeedback, isAnonymous: e.target.checked})}
                />
                <label htmlFor="anonymous" className="ml-2 block text-sm text-gray-700 dark:text-gray-300">
                  Submit anonymously
                </label>
              </div>
              
              {/* Information box */}
              <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-md mb-6">
                <div className="flex">
                  <div className="flex-shrink-0">
                    <Info className="h-5 w-5 text-blue-400" />
                  </div>
                  <div className="ml-3">
                    <p className="text-sm text-blue-700 dark:text-blue-300">
                      {feedbackType === 'women' 
                        ? 'This feedback channel is specifically designed for women students to report any safety concerns or uncomfortable situations. Your report will be handled with the utmost confidentiality.' 
                        : 'Your feedback is important to us! All feedback is reviewed by the appropriate authorities and actions are taken based on merit.'}
                    </p>
                  </div>
                </div>
              </div>
              
              {/* Submit button */}
              <div className="flex justify-end">
                <button
                  type="submit"
                  className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                >
                  <Send size={16} className="mr-2" />
                  Submit Feedback
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Previous Feedback List */}
      {activeTab === 'previous' && (
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow">
          <div className="p-6">
            <h2 className="text-lg font-medium text-gray-800 dark:text-white mb-4">
              Your Previous Feedback
            </h2>
            
            {previousFeedback.length === 0 ? (
              <div className="text-center py-6">
                <AlertCircle size={48} className="mx-auto text-gray-400" />
                <h3 className="mt-2 text-base font-medium text-gray-800 dark:text-white">No feedback submitted</h3>
                <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                  You haven't submitted any feedback yet.
                </p>
                <button
                  type="button"
                  onClick={() => setActiveTab('new')}
                  className="mt-4 inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                >
                  <ArrowRightCircle size={16} className="mr-2" />
                  Submit New Feedback
                </button>
              </div>
            ) : (
              <div className="divide-y divide-gray-200 dark:divide-gray-700">
                {previousFeedback.map((feedback) => (
                  <div key={feedback.id} className="py-4">
                    <div className="flex items-center justify-between">
                      <h3 className="text-base font-medium text-gray-800 dark:text-white">
                        {feedback.subject}
                      </h3>
                      {getStatusBadge(feedback.status)}
                    </div>
                    
                    <div className="mt-1 flex flex-wrap text-sm text-gray-500 dark:text-gray-400">
                      <p className="mr-4">
                        <span className="font-medium">Type:</span> {feedback.type === 'faculty' ? 'Faculty Feedback' : feedback.type === 'general' ? 'General Feedback' : 'Women\'s Safety'}
                      </p>
                      
                      {feedback.targetName && (
                        <p className="mr-4">
                          <span className="font-medium">Faculty:</span> {feedback.targetName}
                        </p>
                      )}
                      
                      {feedback.course && (
                        <p className="mr-4">
                          <span className="font-medium">Course:</span> {feedback.course}
                        </p>
                      )}
                      
                      <p>
                        <span className="font-medium">Date:</span> {new Date(feedback.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                      </p>
                    </div>
                    
                    <div className="mt-2 text-sm text-gray-600 dark:text-gray-300">
                      {feedback.content}
                    </div>
                    
                    <div className="mt-2 text-xs text-gray-500 dark:text-gray-400 flex items-center">
                      {feedback.isAnonymous ? (
                        <span className="flex items-center">
                          <Lock size={12} className="mr-1" />
                          Submitted anonymously
                        </span>
                      ) : (
                        <span>Submitted with your identity</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default StudentFeedback;