import React from 'react';

const Timetable = () => {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-6">Class Timetable</h1>
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
            <thead className="bg-gray-50 dark:bg-gray-900">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Time</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Monday</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Tuesday</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Wednesday</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Thursday</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Friday</th>
              </tr>
            </thead>
            <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
              {[
                { time: '9:00 AM - 10:00 AM', classes: ['Mathematics', 'Physics', 'Chemistry', 'Biology', 'English'] },
                { time: '10:00 AM - 11:00 AM', classes: ['Physics', 'Chemistry', 'Biology', 'English', 'Mathematics'] },
                { time: '11:00 AM - 12:00 PM', classes: ['Chemistry', 'Biology', 'English', 'Mathematics', 'Physics'] },
                { time: '12:00 PM - 1:00 PM', classes: ['Lunch Break', 'Lunch Break', 'Lunch Break', 'Lunch Break', 'Lunch Break'] },
                { time: '1:00 PM - 2:00 PM', classes: ['Biology', 'English', 'Mathematics', 'Physics', 'Chemistry'] },
                { time: '2:00 PM - 3:00 PM', classes: ['English', 'Mathematics', 'Physics', 'Chemistry', 'Biology'] },
              ].map((row, rowIndex) => (
                <tr key={rowIndex}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-gray-100">
                    {row.time}
                  </td>
                  {row.classes.map((subject, index) => (
                    <td key={index} className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                      {subject}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Timetable;