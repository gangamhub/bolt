import React, { createContext, useContext, useState, useEffect } from 'react';

// Define types for our context
type User = {
  id: string;
  name: string;
  email: string;
  role: 'student' | 'faculty' | 'admin';
  avatarUrl?: string;
};

type AuthContextType = {
  currentUser: User | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<User>;
  register: (name: string, email: string, password: string, role: 'student' | 'faculty' | 'admin') => Promise<User>;
  logout: () => void;
  forgotPassword: (email: string) => Promise<void>;
};

// Mock users for demo (will be replaced by API calls to backend)
const MOCK_USERS: User[] = [
  {
    id: '1',
    name: 'John Student',
    email: 'student@example.com',
    role: 'student',
    avatarUrl: 'https://randomuser.me/api/portraits/men/1.jpg',
  },
  {
    id: '2',
    name: 'Jane Faculty',
    email: 'faculty@example.com',
    role: 'faculty',
    avatarUrl: 'https://randomuser.me/api/portraits/women/1.jpg',
  },
  {
    id: '3',
    name: 'Admin User',
    email: 'admin@example.com',
    role: 'admin',
    avatarUrl: 'https://randomuser.me/api/portraits/men/2.jpg',
  },
];

// Create context
const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Create provider component
export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  // Check for saved user on mount
  useEffect(() => {
    const savedUser = localStorage.getItem('currentUser');
    if (savedUser) {
      setCurrentUser(JSON.parse(savedUser));
    }
    setLoading(false);
  }, []);

  // Login function (mock)
  const login = async (email: string, password: string): Promise<User> => {
    // Simulate API call
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const user = MOCK_USERS.find(u => u.email === email);
        if (user) {
          setCurrentUser(user);
          localStorage.setItem('currentUser', JSON.stringify(user));
          resolve(user);
        } else {
          reject(new Error('Invalid email or password'));
        }
      }, 1000);
    });
  };

  // Register function (mock)
  const register = async (
    name: string, 
    email: string, 
    password: string, 
    role: 'student' | 'faculty' | 'admin'
  ): Promise<User> => {
    // Simulate API call
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const existingUser = MOCK_USERS.find(u => u.email === email);
        if (existingUser) {
          reject(new Error('Email already in use'));
        } else {
          const newUser: User = {
            id: Math.random().toString(36).substr(2, 9),
            name,
            email,
            role,
          };
          
          // In a real app, this would be an API call to save the user
          setCurrentUser(newUser);
          localStorage.setItem('currentUser', JSON.stringify(newUser));
          resolve(newUser);
        }
      }, 1000);
    });
  };

  // Logout function
  const logout = () => {
    setCurrentUser(null);
    localStorage.removeItem('currentUser');
  };

  // Forgot password function (mock)
  const forgotPassword = async (email: string): Promise<void> => {
    // Simulate API call
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const user = MOCK_USERS.find(u => u.email === email);
        if (user) {
          // In a real app, this would send an email
          console.log(`Password reset email sent to ${email}`);
          resolve();
        } else {
          reject(new Error('No account found with this email'));
        }
      }, 1000);
    });
  };

  const value = {
    currentUser,
    loading,
    login,
    register,
    logout,
    forgotPassword,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

// Custom hook to use auth context
export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};